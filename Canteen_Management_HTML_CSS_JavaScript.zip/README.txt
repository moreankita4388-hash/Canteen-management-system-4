CAMPUS CANTEEN MANAGEMENT SYSTEM
Frontend Project using HTML, CSS and JavaScript

FILES
- index.html : Page structure and forms
- style.css  : Responsive design and styling
- script.js  : Menu, cart, bill, order and admin functionality

HOW TO RUN
1. Extract this ZIP file.
2. Open the extracted folder.
3. Double-click index.html, or open it with Chrome/Edge/Firefox.
4. Add food to cart, enter a name and place an order.
5. Use the Admin Dashboard to view orders, update order status, delete orders,
   clear order history and add food items.

FEATURES
- Responsive canteen website
- Food menu and search
- Add to cart and change quantity
- Automatic subtotal, 5% demo tax and total
- Place orders
- Admin dashboard, sales total and order status
- Add food items
- Saves data in browser localStorage

IMPORTANT PROJECT NOTE
This is a front-end educational demo. Data is saved only in the same browser
using localStorage. It does not use a server/database, real user accounts or
online payment. The Admin Dashboard is not password protected. Do not use this
demo for real customer data or public deployment without a secure backend,
authentication and database.
