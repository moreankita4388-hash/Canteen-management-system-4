const defaultFoods = [
  {id:1,name:"Tea",price:10,emoji:"☕"},
  {id:2,name:"Coffee",price:20,emoji:"🥤"},
  {id:3,name:"Poha",price:25,emoji:"🍲"},
  {id:4,name:"Sandwich",price:40,emoji:"🥪"},
  {id:5,name:"Vadapav",price:20,emoji:"🍔"},
  {id:6,name:"Misal Pav",price:50,emoji:"🍛"},
  {id:7,name:"Veg Pizza",price:80,emoji:"🍕"},
  {id:8,name:"Samosa",price:15,emoji:"🥟"},
  {id:9,name:"Fresh Juice",price:35,emoji:"🧃"}
];

const read = (key, fallback) => {
  try { const value = localStorage.getItem(key); return value ? JSON.parse(value) : fallback; }
  catch { return fallback; }
};
let foods = read("canteen_foods", defaultFoods);
let cart = [];
let orders = read("canteen_orders", []);
const money = n => "₹" + Number(n).toFixed(2);
const save = () => {
  localStorage.setItem("canteen_foods", JSON.stringify(foods));
  localStorage.setItem("canteen_orders", JSON.stringify(orders));
};

function renderMenu(filter="") {
  const list = document.getElementById("menu-list");
  const found = foods.filter(f => f.name.toLowerCase().includes(filter.toLowerCase()));
  list.innerHTML = found.length ? found.map(f => `
    <article class="food-card">
      <div class="food-emoji">${escapeHTML(f.emoji)}</div>
      <h3>${escapeHTML(f.name)}</h3>
      <div class="food-bottom"><span class="price">${money(f.price)}</span>
      <button class="small-btn" onclick="addToCart(${f.id})">Add to Cart +</button></div>
    </article>`).join("") : '<p class="muted">No food item found.</p>';
}
function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, ch => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[ch]));
}
function addToCart(id) {
  const food = foods.find(f => f.id === id);
  if (!food) return;
  const existing = cart.find(i => i.id === id);
  if (existing) existing.qty++; else cart.push({...food,qty:1});
  renderCart();
}
function changeQty(id, amount) {
  const item = cart.find(i => i.id === id);
  if (!item) return;
  item.qty += amount;
  if (item.qty <= 0) cart = cart.filter(i => i.id !== id);
  renderCart();
}
function renderCart() {
  const container = document.getElementById("cart-items");
  const count = cart.reduce((sum,i)=>sum+i.qty,0);
  document.getElementById("cart-count").textContent = count;
  if (!cart.length) container.innerHTML = '<p class="muted">Your cart is empty. Add something tasty!</p>';
  else container.innerHTML = cart.map(i => `
    <div class="cart-row"><div><strong>${escapeHTML(i.emoji)} ${escapeHTML(i.name)}</strong><small>${money(i.price)} each</small></div>
    <div class="qty-controls"><button onclick="changeQty(${i.id},-1)" aria-label="Decrease quantity">−</button><strong>${i.qty}</strong><button onclick="changeQty(${i.id},1)" aria-label="Increase quantity">+</button></div>
    <strong>${money(i.price*i.qty)}</strong></div>`).join("");
  const subtotal = cart.reduce((sum,i)=>sum+i.price*i.qty,0);
  const tax = Math.round(subtotal*0.05*100)/100;
  document.getElementById("subtotal").textContent = money(subtotal);
  document.getElementById("tax").textContent = money(tax);
  document.getElementById("total").textContent = money(subtotal+tax);
}
function placeOrder() {
  const name = document.getElementById("customer-name").value.trim();
  const message = document.getElementById("order-message");
  if (!cart.length) { message.textContent = "Please add food items to your cart."; return; }
  if (!name) { message.textContent = "Please enter your name."; document.getElementById("customer-name").focus(); return; }
  const subtotal = cart.reduce((sum,i)=>sum+i.price*i.qty,0);
  const total = subtotal + Math.round(subtotal*0.05*100)/100;
  const order = {id:Date.now(),name,items:cart.map(i=>({name:i.name,qty:i.qty})),total,status:"Received"};
  orders.unshift(order); save(); cart=[]; document.getElementById("customer-name").value="";
  renderCart(); renderAdmin();
  message.textContent = `Order placed successfully! Your order number is #${String(order.id).slice(-6)}.`;
}
function renderAdmin() {
  document.getElementById("orders-count").textContent = orders.length;
  document.getElementById("sales-total").textContent = money(orders.reduce((s,o)=>s+o.total,0));
  const tbody = document.getElementById("orders-table");
  if (!orders.length) { tbody.innerHTML='<tr><td colspan="6" class="muted">No orders yet.</td></tr>'; return; }
  tbody.innerHTML = orders.map(o=>`<tr>
    <td>#${String(o.id).slice(-6)}</td><td>${escapeHTML(o.name)}</td>
    <td>${o.items.map(i=>`${escapeHTML(i.name)} × ${i.qty}`).join(", ")}</td>
    <td>${money(o.total)}</td><td>${escapeHTML(o.status)}</td>
    <td><button class="status-btn" onclick="toggleStatus(${o.id})">Update</button>
    <button class="delete-btn" onclick="deleteOrder(${o.id})">Delete</button></td></tr>`).join("");
}
function toggleStatus(id) {
  const order = orders.find(o=>o.id===id);
  if (!order) return;
  order.status = order.status==="Received" ? "Preparing" : order.status==="Preparing" ? "Ready" : "Received";
  save(); renderAdmin();
}
function deleteOrder(id) {
  if (!confirm("Delete this order?")) return;
  orders = orders.filter(o=>o.id!==id); save(); renderAdmin();
}
document.getElementById("search").addEventListener("input",e=>renderMenu(e.target.value));
document.getElementById("place-order").addEventListener("click",placeOrder);
document.getElementById("clear-orders").addEventListener("click",()=>{
  if (confirm("Clear all order history?")) { orders=[]; save(); renderAdmin(); }
});
document.getElementById("add-food-form").addEventListener("submit",e=>{
  e.preventDefault();
  const name=document.getElementById("food-name").value.trim();
  const price=Number(document.getElementById("food-price").value);
  const emoji=document.getElementById("food-emoji").value.trim() || "🍽️";
  if (!name || !Number.isFinite(price) || price<=0) return;
  foods.push({id:Date.now(),name,price,emoji}); save(); renderMenu(document.getElementById("search").value);
  e.target.reset(); document.getElementById("food-emoji").value="🍽️";
});
renderMenu(); renderCart(); renderAdmin();
